/**
 * Drizzle schema — single source of truth for both the generated SQL
 * migrations (`npm run db:generate`) and the TypeScript types used by the
 * repository layer. Mirrors the schema approved in the architecture audit
 * 1:1 — see product-data-architecture-audit.md §4.
 *
 * Naming: snake_case column names (Postgres convention) via drizzle's
 * explicit column-name argument; camelCase on the JS/TS side.
 */
import {
  pgTable,
  text,
  integer,
  bigint,
  boolean,
  timestamp,
  primaryKey,
  uniqueIndex,
  index,
  check,
} from 'drizzle-orm/pg-core';
import { sql } from 'drizzle-orm';

const locale = () => text('locale');
const localeCheck = (table: { locale: ReturnType<typeof locale> }) =>
  check('locale_check', sql`${table.locale} IN ('vi', 'zh')`);

// ---------------------------------------------------------------------------
// categories
// ---------------------------------------------------------------------------
export const categories = pgTable('categories', {
  id: text('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  parentId: text('parent_id'),
  sortOrder: integer('sort_order').notNull().default(0),
  isPublished: boolean('is_published').notNull().default(true),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index('idx_categories_parent').on(table.parentId),
]);

// ---------------------------------------------------------------------------
// category_translations
// ---------------------------------------------------------------------------
export const categoryTranslations = pgTable('category_translations', {
  categoryId: text('category_id').notNull().references(() => categories.id, { onDelete: 'cascade' }),
  locale: locale().notNull(),
  name: text('name').notNull(),
  description: text('description'),
}, (table) => [
  primaryKey({ columns: [table.categoryId, table.locale] }),
  localeCheck(table),
]);

// ---------------------------------------------------------------------------
// products
// ---------------------------------------------------------------------------
export const products = pgTable('products', {
  id: text('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  categoryId: text('category_id').notNull().references(() => categories.id),
  isFeatured: boolean('is_featured').notNull().default(false),
  isPublished: boolean('is_published').notNull().default(false),
  sortOrder: integer('sort_order').notNull().default(0),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index('idx_products_category').on(table.categoryId),
  index('idx_products_featured').on(table.isFeatured).where(sql`${table.isFeatured} = true`),
  index('idx_products_published').on(table.isPublished).where(sql`${table.isPublished} = true`),
]);

// ---------------------------------------------------------------------------
// product_translations
// ---------------------------------------------------------------------------
export const productTranslations = pgTable('product_translations', {
  productId: text('product_id').notNull().references(() => products.id, { onDelete: 'cascade' }),
  locale: locale().notNull(),
  name: text('name').notNull(),
  shortDescription: text('short_description'),
  description: text('description'),
  ingredients: text('ingredients'),
  usageInstructions: text('usage_instructions'),
}, (table) => [
  primaryKey({ columns: [table.productId, table.locale] }),
  localeCheck(table),
]);

// ---------------------------------------------------------------------------
// product_benefits
// ---------------------------------------------------------------------------
export const productBenefits = pgTable('product_benefits', {
  id: text('id').primaryKey(),
  productId: text('product_id').notNull().references(() => products.id, { onDelete: 'cascade' }),
  locale: locale().notNull(),
  sortOrder: integer('sort_order').notNull().default(0),
  text: text('text').notNull(),
}, (table) => [
  index('idx_product_benefits_product').on(table.productId, table.locale, table.sortOrder),
  localeCheck(table),
]);

// ---------------------------------------------------------------------------
// product_images
// ---------------------------------------------------------------------------
export const productImages = pgTable('product_images', {
  id: text('id').primaryKey(),
  productId: text('product_id').notNull().references(() => products.id, { onDelete: 'cascade' }),
  url: text('url').notNull(),
  role: text('role').notNull(),
  width: integer('width').notNull(),
  height: integer('height').notNull(),
  sortOrder: integer('sort_order').notNull().default(0),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  uniqueIndex('idx_product_images_one_primary').on(table.productId).where(sql`${table.role} = 'primary'`),
  index('idx_product_images_product').on(table.productId, table.sortOrder),
  check('product_images_role_check', sql`${table.role} IN ('primary', 'gallery', 'thumbnail')`),
]);

// ---------------------------------------------------------------------------
// product_image_translations
// ---------------------------------------------------------------------------
export const productImageTranslations = pgTable('product_image_translations', {
  imageId: text('image_id').notNull().references(() => productImages.id, { onDelete: 'cascade' }),
  locale: locale().notNull(),
  alt: text('alt').notNull(),
}, (table) => [
  primaryKey({ columns: [table.imageId, table.locale] }),
  localeCheck(table),
]);

// ---------------------------------------------------------------------------
// product_variants
// ---------------------------------------------------------------------------
export const productVariants = pgTable('product_variants', {
  id: text('id').primaryKey(),
  productId: text('product_id').notNull().references(() => products.id, { onDelete: 'cascade' }),
  sku: text('sku').notNull().unique(),
  isDefault: boolean('is_default').notNull().default(false),
  sortOrder: integer('sort_order').notNull().default(0),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  uniqueIndex('idx_variants_one_default').on(table.productId).where(sql`${table.isDefault} = true`),
  index('idx_variants_product').on(table.productId),
]);

// ---------------------------------------------------------------------------
// product_variant_translations
// ---------------------------------------------------------------------------
export const productVariantTranslations = pgTable('product_variant_translations', {
  variantId: text('variant_id').notNull().references(() => productVariants.id, { onDelete: 'cascade' }),
  locale: locale().notNull(),
  label: text('label').notNull(),
}, (table) => [
  primaryKey({ columns: [table.variantId, table.locale] }),
  localeCheck(table),
]);

// ---------------------------------------------------------------------------
// pricing (time-versioned; "current" price = latest row where
// effective_from <= now() < effective_to (or effective_to IS NULL))
// ---------------------------------------------------------------------------
export const pricing = pgTable('pricing', {
  id: text('id').primaryKey(),
  variantId: text('variant_id').notNull().references(() => productVariants.id, { onDelete: 'cascade' }),
  priceMinor: bigint('price_minor', { mode: 'number' }).notNull(),
  compareAtMinor: bigint('compare_at_minor', { mode: 'number' }),
  currency: text('currency').notNull().default('VND'),
  effectiveFrom: timestamp('effective_from', { withTimezone: true }).notNull().defaultNow(),
  effectiveTo: timestamp('effective_to', { withTimezone: true }),
}, (table) => [
  index('idx_pricing_variant_active').on(table.variantId, table.effectiveFrom),
]);

// ---------------------------------------------------------------------------
// inventory
// ---------------------------------------------------------------------------
export const inventory = pgTable('inventory', {
  variantId: text('variant_id').primaryKey().references(() => productVariants.id, { onDelete: 'cascade' }),
  quantity: integer('quantity'),
  lowStockThreshold: integer('low_stock_threshold'),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
});
