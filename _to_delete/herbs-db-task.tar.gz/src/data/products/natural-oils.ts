import type { ImageMetadata } from 'astro:assets';

export type CategoryId = 'natural-oils';

export interface ProductLocaleFields {
  name: string;
}

export interface Product {
  id: string; // stable id
  slug: string; // stable English slug used in URLs
  category: CategoryId;
  image: ImageMetadata | string; // can be a static path for now
  featured?: boolean;
  vi: ProductLocaleFields;
  zh: ProductLocaleFields;
}

// Single shared placeholder image for now; replace with real assets later.
import oilPlaceholder from '../../assets/images/products/natural-oils/oil-placeholder.webp';

export const NATURAL_OILS: Product[] = [
  {
    id: 'natural-oils:coconut-oil',
    slug: 'coconut-oil',
    category: 'natural-oils',
    image: oilPlaceholder,
    featured: true,
    vi: { name: 'Dầu dừa' },
    zh: { name: '椰子油' },
  },
  {
    id: 'natural-oils:rice-bran-oil',
    slug: 'rice-bran-oil',
    category: 'natural-oils',
    image: oilPlaceholder,
    vi: { name: 'Dầu cám gạo' },
    zh: { name: '米糠油' },
  },
  {
    id: 'natural-oils:peanut-oil',
    slug: 'peanut-oil',
    category: 'natural-oils',
    image: oilPlaceholder,
    vi: { name: 'Dầu đậu phộng' },
    zh: { name: '花生油' },
  },
  {
    id: 'natural-oils:sunflower-oil',
    slug: 'sunflower-oil',
    category: 'natural-oils',
    image: oilPlaceholder,
    featured: true,
    vi: { name: 'Dầu hướng dương' },
    zh: { name: '葵花籽油' },
  },
  {
    id: 'natural-oils:soybean-oil',
    slug: 'soybean-oil',
    category: 'natural-oils',
    image: oilPlaceholder,
    vi: { name: 'Dầu đậu nành' },
    zh: { name: '大豆油' },
  },
  {
    id: 'natural-oils:canola-oil',
    slug: 'canola-oil',
    category: 'natural-oils',
    image: oilPlaceholder,
    vi: { name: 'Dầu cải / Canola' },
    zh: { name: '菜籽油' },
  },
  {
    id: 'natural-oils:palm-oil',
    slug: 'palm-oil',
    category: 'natural-oils',
    image: oilPlaceholder,
    vi: { name: 'Dầu cọ' },
    zh: { name: '棕榈油' },
  },
  {
    id: 'natural-oils:sesame-oil',
    slug: 'sesame-oil',
    category: 'natural-oils',
    image: oilPlaceholder,
    featured: true,
    vi: { name: 'Dầu mè' },
    zh: { name: '芝麻油' },
  },
  {
    id: 'natural-oils:olive-oil',
    slug: 'olive-oil',
    category: 'natural-oils',
    image: oilPlaceholder,
    featured: true,
    vi: { name: 'Dầu olive' },
    zh: { name: '橄榄油' },
  },
  {
    id: 'natural-oils:avocado-oil',
    slug: 'avocado-oil',
    category: 'natural-oils',
    image: oilPlaceholder,
    vi: { name: 'Dầu avocado' },
    zh: { name: '牛油果油' },
  },
];

export function featuredNaturalOils(limit = 4): Product[] {
  const featured = NATURAL_OILS.filter((p) => p.featured);
  return (featured.length ? featured : NATURAL_OILS).slice(0, limit);
}

