/**
 * Build-time-only Postgres connection. Imported exclusively by
 * src/server/repositories/postgres/*.ts (and the migrate/seed scripts) —
 * never by an Astro component, never by client-side code. Because
 * astro.config.mjs has no `output`/adapter set, Astro stays fully static:
 * this module only ever runs inside the Node process that executes
 * `astro build` (or the standalone migrate/seed/tsx scripts), not per
 * request and not in the browser.
 */
import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import * as schema from '../../db/schema';

try {
  process.loadEnvFile();
} catch {
  // .env not present — rely on a real environment variable (e.g. CI secret).
}

const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  throw new Error(
    'DATABASE_URL is not set. Copy .env.example to .env and set a PostgreSQL ' +
    'connection string before running the build, db:migrate, or db:seed.'
  );
}

const pool = new Pool({ connectionString });

export const db = drizzle(pool, { schema });
