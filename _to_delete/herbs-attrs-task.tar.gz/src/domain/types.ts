/**
 * Canonical, locale-RESOLVED read models handed from the repository layer
 * to Astro pages. "Resolved" means: the caller already picked a locale
 * (see repository method signatures), so these types carry plain strings
 * (`name: string`), never `Record<Locale, string>` — components never
 * choose a locale themselves, they just render whatever string they're
 * given. This mirrors src/i18n/utils.ts's `Locale` union deliberately, so
 * page code can pass the same `lang` value through both systems.
 */
export type Locale = 'vi' | 'zh';

export interface LocalizedImage {
  id: string;
  url: string;
  alt: string;
  width: number;
  height: number;
  role: 'primary' | 'gallery' | 'thumbnail';
  sortOrder: number;
}

export interface ProductVariantView {
  id: string;
  sku: string;
  label: string;
  isDefault: boolean;
  priceMinor: number | null;
  compareAtMinor: number | null;
  currency: string | null;
  inventoryQuantity: number | null;
}

export interface CategoryView {
  id: string;
  slug: string;
  locale: Locale;
  name: string;
  description: string | null;
}

/** Full detail view for a single product detail page (PDP). */
export interface ProductDetailView {
  id: string;
  slug: string;
  categoryId: string;
  locale: Locale;
  name: string;
  shortDescription: string | null;
  description: string | null;
  ingredients: string | null;
  usage: string | null;
  benefits: string[];
  images: LocalizedImage[];
  variants: ProductVariantView[];
  isFeatured: boolean;
  isPublished: boolean;
}

/**
 * Lighter read model for grid/carousel views (listing pages, homepage
 * featured rail) — deliberately excludes description/benefits/full variant
 * list so a page rendering 10-40 cards doesn't pull content it won't render.
 */
export interface ProductSummaryView {
  id: string;
  slug: string;
  categoryId: string;
  locale: Locale;
  name: string;
  isFeatured: boolean;
  primaryImage: LocalizedImage | null;
  priceMinor: number | null;
  compareAtMinor: number | null;
  currency: string | null;
}
