/**
 * Better Auth instance — Phase 1 (Admin Foundation).
 *
 * Runs per-request inside the Node adapter for /admin/*, /api/admin/*, and
 * the catch-all handler at /api/auth/[...all] (see astro.config.mjs). Never
 * imported by a prerendered storefront page.
 *
 * Scope, per the Better Auth audit:
 *   - email/password only, sign-up disabled (single pre-seeded operator
 *     account — see scripts/seed-admin.ts). No social providers, no
 *     magic-link, no OTP, no anonymous-user or username plugins, no
 *     custom registration endpoint.
 *   - Database-backed sessions (Better Auth's default — no JWT plugin),
 *     default 7-day expiration / 1-day rolling refresh, unchanged.
 *   - Custom Argon2id hashing (src/server/auth/argon2.ts) in place of
 *     Better Auth's default Scrypt.
 *   - Our own `admin_`-prefixed tables (src/db/schema.ts), mapped in via
 *     the Drizzle adapter's `schema` option plus explicit
 *     `modelName`/`fields` on each of user/session/account/verification,
 *     rather than letting Better Auth's CLI generate/own the schema.
 *   - No role/RBAC config here — single-operator for this phase; the
 *     middleware (src/middleware.ts) only checks "is there a valid
 *     session", nothing more.
 */
import { betterAuth } from 'better-auth/minimal';
import { drizzleAdapter } from 'better-auth/adapters/drizzle';
import { db } from '../db/client';
import {
  adminUsers,
  adminSessions,
  adminAccounts,
  adminVerifications,
} from '../../db/schema';
import { hashPassword, verifyPassword } from './argon2';

try {
  process.loadEnvFile();
} catch {
  // .env not present — rely on real environment variables (e.g. CI/host secrets).
}

const authSecret = process.env.BETTER_AUTH_SECRET;
if (!authSecret) {
  throw new Error(
    'BETTER_AUTH_SECRET is not set. Set it in .env (see .env.example) before ' +
    'running the dev server, build, or the admin seed script.'
  );
}

export const auth = betterAuth({
  secret: authSecret,
  baseURL: process.env.BETTER_AUTH_URL, // e.g. https://admin.example.com — required in production

  database: drizzleAdapter(db, {
    provider: 'pg',
    schema: {
      user: adminUsers,
      session: adminSessions,
      account: adminAccounts,
      verification: adminVerifications,
    },
  }),

  // Explicit modelName/fields mapping per the audit, on top of the
  // `schema` mapping above: our column names already match Better Auth's
  // canonical field names 1:1 (see src/db/schema.ts's comment block), so
  // `fields` has nothing to remap today — `modelName` is what actually
  // does the work of pointing each model at our `admin_`-prefixed table.
  user: {
    modelName: 'admin_users',
    fields: {},
  },
  session: {
    modelName: 'admin_sessions',
    fields: {},
    // Defaults, unchanged — flagging explicitly per the audit rather than
    // silently relying on them:
    expiresIn: 60 * 60 * 24 * 7, // 7 days
    updateAge: 60 * 60 * 24, // 1 day rolling refresh
  },
  account: {
    modelName: 'admin_accounts',
    fields: {},
  },
  verification: {
    modelName: 'admin_verifications',
    fields: {},
  },

  emailAndPassword: {
    enabled: true,
    disableSignUp: true,
    password: {
      hash: hashPassword,
      verify: ({ hash, password }) => verifyPassword(hash, password),
    },
  },

  // No socialProviders, no plugins (no magic-link, no email-otp, no
  // anonymous, no username) — deliberate, per the audit.
});
