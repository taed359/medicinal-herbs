// @ts-check
import { defineConfig } from 'astro/config';

import tailwindcss from '@tailwindcss/vite';
import node from '@astrojs/node';

// https://astro.build/config
//
// `output: 'static'` is explicit (it's also the default) — the storefront
// (/, /products/*, /vi/*, /zh/*, etc.) is prerendered at build time as
// before; nothing about those routes changes. The `node` adapter is added
// only so that the small set of routes that opt out via
// `export const prerender = false` (the /admin/* pages, /api/admin/*, and
// the Better Auth catch-all at /api/auth/[...all]) have a server runtime
// to actually run on — Astro's hybrid rendering requires an adapter for
// any on-demand route even when the project-level output stays 'static'.
// This does NOT switch the project to `output: 'server'`.
export default defineConfig({
  output: 'static',
  adapter: node({ mode: 'standalone' }),
  i18n: {
    defaultLocale: 'en',
    locales: ['en', 'vi', 'zh'],
    routing: {
      prefixDefaultLocale: false
    }
  },
  vite: {
    plugins: [tailwindcss()]
  }
});
