/**
 * Shared Postgres connection (Drizzle + node-postgres pool). Never imported
 * by client-side code.
 *
 * Two distinct runtime lifetimes use this same module, since Phase 1 added
 * a small set of on-demand (non-prerendered) routes alongside the fully
 * static storefront:
 *   - Storefront pages (src/pages/**\/*.astro, no `prerender = false`) and
 *     the migrate/seed/tsx scripts: read this only inside the Node process
 *     that runs `astro build` (or the script itself) — build-time only,
 *     same as before.
 *   - /admin/*, /api/admin/*, and /api/auth/[...all] (each explicitly
 *     `export const prerender = false` — see astro.config.mjs, which adds
 *     the `@astrojs/node` adapter for exactly these routes while the
 *     project-level `output` stays 'static'): these run per-request via
 *     the Node adapter, so this pool is also a long-lived, per-process
 *     connection pool for admin/auth traffic, not a build-time-only one.
 */
import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import * as schema from '../../db/schema';

try {
  process.loadEnvFile();
} catch {
  // .env not present — rely on a real environment variable (e.g. CI secret).
}

const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  throw new Error(
    'DATABASE_URL is not set. Copy .env.example to .env and set a PostgreSQL ' +
    'connection string before running the build, db:migrate, or db:seed.'
  );
}

const pool = new Pool({ connectionString });

export const db = drizzle(pool, { schema });
